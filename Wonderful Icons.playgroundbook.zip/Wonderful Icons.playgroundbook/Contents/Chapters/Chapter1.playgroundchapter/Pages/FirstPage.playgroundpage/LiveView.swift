import SwiftUI
import PlaygroundSupport
import AuxiliaryModule

PlaygroundPage.current.setLiveView(DesigningAnimatedLiveView())

