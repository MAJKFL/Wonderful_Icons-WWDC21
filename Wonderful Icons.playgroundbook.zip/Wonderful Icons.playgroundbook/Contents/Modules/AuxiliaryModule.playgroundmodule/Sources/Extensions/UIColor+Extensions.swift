//
//  UIColor+Extensions.swift
//  PlaygroundBook
//
//  Created by Kuba Florek on 17/04/2021.
//

import SwiftUI

public extension UIColor {
    var coreImageColor: CIColor {
        return CIColor(color: self)
    }
    
    var components: (red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat) {
        let coreImageColor = self.coreImageColor
        return (coreImageColor.red, coreImageColor.green, coreImageColor.blue, coreImageColor.alpha)
    }
    
    func colorDistanceBetween(uicolor: UIColor) -> Float {
        let firstColorComponents = self.components
        let secondColorComponents = uicolor.components
        
        return Float(pow(secondColorComponents.red - firstColorComponents.red, 2) + pow(secondColorComponents.green - firstColorComponents.green, 2) + pow(secondColorComponents.blue - firstColorComponents.blue, 2)).squareRoot()
    }
}

public extension UIColor {
    func toColor(_ color: UIColor, percentage: CGFloat) -> UIColor {
        let percentage = max(min(percentage, 100), 0) / 100
        switch percentage {
        case 0: return self
        case 1: return color
        default:
            var (r1, g1, b1, a1): (CGFloat, CGFloat, CGFloat, CGFloat) = (0, 0, 0, 0)
            var (r2, g2, b2, a2): (CGFloat, CGFloat, CGFloat, CGFloat) = (0, 0, 0, 0)
            guard self.getRed(&r1, green: &g1, blue: &b1, alpha: &a1) else { return self }
            guard color.getRed(&r2, green: &g2, blue: &b2, alpha: &a2) else { return self }

            return UIColor(red: CGFloat(r1 + (r2 - r1) * percentage), green: CGFloat(g1 + (g2 - g1) * percentage), blue: CGFloat(b1 + (b2 - b1) * percentage), alpha: CGFloat(a1 + (a2 - a1) * percentage))
        }
    }
}
